import os, struct
GLYPH_SIZE = 30
# with open('wor16.asc', 'rb') as f:
#     f.seek(0, os.SEEK_END)
#     count = f.tell() // 2
#     f.seek(0, os.SEEK_SET)

#     buf_char = [s[0] for s in struct.iter_unpack("<H", f.read())]

#     char_dict = {k: v for v, k in enumerate(buf_char)}
#     print(char_dict)
#     f.seek(0, os.SEEK_SET)
#     buf_char2 = struct.unpack("<%dH" % count, f.read())
#     char_dict2 = {k: v for v, k in enumerate(buf_char2)}
#     print(char_dict2)

# with open('wor16.fon', 'rb') as f:
#     # 字形信息从0x682开始
#     f.seek(0x682, os.SEEK_SET)
#     buf_glyph = [s[0] for s in struct.iter_unpack("%dB" % GLYPH_SIZE, f.read())]
#     print(len(buf_glyph))

WORD_LENGTH = 10
with open('word.dat', 'rb') as f:
    # 获取单词总数
    buf_word = [s[0] for s in struct.iter_unpack("%dB" % WORD_LENGTH, f.read())]
    