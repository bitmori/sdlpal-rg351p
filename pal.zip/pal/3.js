// Sdlpal.get_obj(0x148);
for (var i = 0; i< 6; i++) {
    Sdlpal.get_lvlup_magic(i);
    print("------");
}
