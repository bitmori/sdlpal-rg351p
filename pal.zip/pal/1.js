// Sdlpal.give_cash(20000);
Sdlpal.make_team();
Sdlpal.lock_team();
// Sdlpal.unlock_team();
// Sdlpal.add_item(0x96, 20); // 金蠶王
// Sdlpal.add_item(0xbb, 20); // 玄冥
// Sdlpal.add_item(0x3F, 30); // 金剛
// Sdlpal.add_item(0x67, 20); // 紫菁
// Sdlpal.add_item(0x106, 3); // 五毒
// Sdlpal.add_item(0x95, 50); // 赤血
// Sdlpal.add_item(0xde, 1); // 白虎
// Sdlpal.add_item(0x5d, 30); // 鴛鴦
// Sdlpal.add_item(0x55, 3); // 七心
// Sdlpal.set_exp_multiplier(6);

function add_flower_dance_items() {
    // 梅花镖*10，袖里剑*8，透骨钉*5，无影神针*3，血玲珑*1
    var x = 9;
    Sdlpal.add_item(0x99, 10*x);
    Sdlpal.add_item(0x9a, 8*x);
    Sdlpal.add_item(0x9b, 5*x);
    Sdlpal.add_item(0xa1, 3*x);
    Sdlpal.add_item(0xa2, 1*x);
}

add_flower_dance_items();