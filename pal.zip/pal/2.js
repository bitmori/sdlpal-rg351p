function toUnicodeArray(str) {
	return str.split('').map(function (value, index, array) {
		return value.charCodeAt(0);
	});
}

Sdlpal.rename_game_obj(0x148, toUnicodeArray("雨恨雲愁"));
Sdlpal.rename_game_obj(0x149, toUnicodeArray("風雪冰天"));

// objects_size = 7068 bytes, obj_size = 12
// pal dream 2.11 has 589 objects